function nextpage(){
    window.location = "index2.html";
}

