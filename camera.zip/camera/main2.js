
Webcam.attach("#webcam");

function capture(){
    countdown();
    Webcam.snap(function(selfie) {
        document.getElementById("selfie").innerHTML = '<img id="captured_selfie" src="'+selfie+'">';
    });
}

function countdown(){
    var speech = window.speechSynthesis;
    var speak_data = "taking your selfie in 5 seconds";

    var utterThis = new SpeechSynthesisUtterance(speak_data);
    speech.speak(utterThis);
    Webcam.attach(webcam);

    setTimeout(function()
    {
        capture();
        download();
    },5000);
}
webcam = document.getElementById("webcam");
Webcam.set({
    width:350,
    height:300,
    image_format : 'png',
    png_quality:90
});

function download(){
    link=document.getElementById("download");
    img=document.getElementById("selfie").src;
    link.href=img;
    link.click();
 }
 







 

